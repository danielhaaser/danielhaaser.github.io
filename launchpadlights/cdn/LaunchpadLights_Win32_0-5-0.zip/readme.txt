LaunchpadLights 0.5.0

Most DAWs ignore MIDI output from VSTs by default, so you will probably have to set it up so that it's sent to your Launchpad.

If you find any bugs or have any feedback, you can find me at
danhaaser@gmail.com

Daniel Haaser
